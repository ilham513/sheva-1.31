<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Indeks extends CI_Controller {
	public function index(){ //sheva.my.id
		$this->load->view('sheva/indeks_view');
	}
}