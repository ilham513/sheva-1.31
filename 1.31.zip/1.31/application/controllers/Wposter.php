<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wposter extends CI_Controller {
	public function index(){
		$data['main_title'] = 'Sheva WPoster';
		$data['main_view'] = 'sheva/wposter_view';
		$this->load->view('layout/bootstrap',$data);
	}

}