<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sbot extends CI_Controller {
	public function index(){
		$data['main_title'] = 'My Sbot Indeks';
		$data['main_view'] = 'sheva/sbot_view';

		$this->load->view('layout/bootstrap',$data);
	}

	public function anime($par='',$par2=''){
		$this->load->helper('shtml');
		$this->load->model('sbot_model');

		## $par = ''; //JADI MASUK KE DEFAULT SWITCH			

		switch ($par):
			case 'anitoki': #SBOT/ANIME/ANITOKI
				$ret = '
				  <div class="btn-group btn-group-justified btn-block">
				    <a href="'.base_url().'sbot/anime/anitoki/post" class="btn btn-primary btn-lg">	Post</a>
				    <a href="'.base_url().'sbot/anime/anitoki/indeks" class="btn btn-primary btn-lg">Indeks</a>
				    <a href="'.base_url().'sbot/anime/anitoki/reset" class="btn btn-primary btn-lg"> Reset</a>				    
				    <a href="'.base_url().'sbot/anime/anitoki/select" class="btn btn-primary btn-lg"> SELECT *</a>
				  </div>
				';

				if($par2=='post'){ #INI POSTNYA

					$url_target = $this->sbot_model->anitokigetpost();
					$ret = 'POST TERAMBIL: '.$url_target. "\t". //MYPOST = url
					'<a href="../anitoki"><button type="button" class="btn btn-lg btn-outline-primary">Back</button></a>';

					$data['url_target'] =  $url_target;


				}elseif($par2=='reset'){ #INI RESET
				    die('reset error!');
				// 	$this->sbot_model->anitokiresetindeks();
				// 	$ret = 'DATA TERESET'.'<hr/>
				// 	<a href="../youtube">
				// 	<button type="button" class="btn btn-light btn-lg btn-block">Kembali</button>
				// 	</a>
				// 	';
				}elseif($par2=='indeks'){ #INI INDEKSNYA
					$this->sbot_model->anitokigetindeks();	
					$ret = 'INDEKS KEAMBIL 
					  <a href="../anitoki"><button type="button" class="btn btn-lg btn-outline-primary">Back</button></a>';
				}elseif($par2=='select'){
				    $this->sbot_model->selectanitoki();
				    echo 'ini select'; die();
				}

				$data['content'] = $ret;

			break;

			default:
				$data['content'] = '
				<a href="anime/anitoki">
				<button type="button" class="btn btn-secondary btn-lg btn-block">Anitoki</button>
				</a>';
		endswitch;

		$data['main_title'] = "'Sbot Anime $par $par2'";
		$data['main_view'] = 'sheva/sbot/anime_view';

		// $data['test'] = $this->sbot_model->getindeks();

		$this->load->view('layout/bootstrap',$data);
	}

	public function trend($par1='', $par2=''){
		$this->load->model('sbot_model');
		$this->load->helper('shtml');

		$data['breadcumb'] = '
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page">Home</li>
  </ol>
</nav>
		';

		switch ($par1):
			case 'youtube':
				##DEFINE TABLE NAME
				$table_name = 'sbot_trend';

				## BREADCUMB YOUTUBE
				$data['breadcumb'] = '
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="../trend">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Youtube</li>
				  </ol>
				</nav>
				';

				#INDEKS BUTTON, DEFAULT DATACONTENT, ALAU BLOM DISET
				$data['content'] = '
				  <div class="btn-group btn-group-justified btn-block">
				    <a href="'.base_url().'sbot/trend/youtube/post" class="btn btn-primary btn-lg active disabled">Post</a>
				    <a href="'.base_url().'sbot/trend/youtube/indeks" class="btn btn-primary btn-lg">				Indeks</a>
				    <a href="'.base_url().'sbot/trend/youtube/reset" class="btn btn-primary btn-lg">				Reset</a>
				  </div>
				';

				if ($par2=='post') {
					$data['content'] = 'Ini youtube trend post';
				} elseif($par2=='indeks') {
					$data['breadcumb'] = 'beta';
					$data['content'] = $this->sbot_model->youtubegetindeksto('sbot_trend').
					'<hr/>
					<a href="../youtube">
					<button type="button" class="btn btn-light btn-lg btn-block">Kembali</button>
					</a>
					';
				} elseif($par2=='reset') {
				    die('reset error!');
				// 	$data['breadcumb'] = 'beta';

				// 	$data['content'] = $this->sbot_model->youtuberesetto('sbot_trend').
				// 	'<hr/>
				// 	<a href="../youtube">
				// 	<button type="button" class="btn btn-light btn-lg btn-block">Kembali</button>
				// 	</a>
				// 	';
				}

				break;
			
			default:

				$data['content'] = '
				<a href="trend/youtube">
				<button type="button" class="btn btn-secondary btn-lg btn-block">Youtube</button>
				</a>
				';
				break;
		endswitch;

		$par1 = ($par1=='') ? '' : ucfirst($par1) ;
		$par2 = ($par2=='') ? '' : ucfirst($par2) ;

		$data['main_title'] = "Sbot Trend $par1 $par2";
		$data['main_view'] = 'sheva/sbot/trend_view';

		$this->load->view('layout/bootstrap',$data);
	}
}