<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stealer extends CI_Controller {
	public function index(){
		$data['main_title'] = 'Sheva Stealer';
		$data['main_view'] = 'sheva/stealer_view';

		$this->load->view('layout/bootstrap',$data);
	}
	public function action(){
		$this->load->helper('shtml');	

		$data['html_target'] = $this->input->get('html_target');
		$data['target'] = $this->input->get('target');
		$data['target_propery'] = $this->input->get('target_propery');

		$data['main_title'] = 'Hasil Stealer';
		$data['main_view'] = 'sheva/stealer_view';

		$this->load->view('layout/bootstrap',$data);
	}

}