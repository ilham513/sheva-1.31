<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title><? echo $main_title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?echo base_url();?>assets/css/bootstrap.min.css">
	<script src="<?echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?echo base_url();?>assets/js/jquery.min.js"></script>
	<link rel="icon" type="image/png" href="<?echo base_url();?>assets/icon/icon.png" />
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="<?echo base_url();?>">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto"></ul>
        <form acton="forrbiden" method="get" class="form-inline my-2 my-lg-0">
          <input name='q' class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
      </div>
    </nav>

<div class="jumbotron p-3 p-md-5 text-white rounded" style="background-color:#777;">
        <div class="col-md-6 px-0" style="padding: 5rem 2rem 2rem;">
          <h1 class="display-4 font-italic"><? echo $main_title; ?></h1>
        </div>
</div>

    <main role="main" class="container">
      <div class="container-fluid">
		    <? $this->load->view($main_view); ?>
      </div>
      <div style="margin-bottom: 80px;"></div>
    </main>
</body>
</html>