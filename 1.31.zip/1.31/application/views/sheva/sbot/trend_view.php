<?php if($breadcumb=='beta'){
		##BREDACUMB-BETA-TEST-MODE STR##
		// echo $_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"];

		$breadcumbs = explode("/",$_SERVER["REQUEST_URI"]);
		$breadcumbs = (array_filter($breadcumbs));

		echo '
		<nav aria-label="breadcrumb">
		  <ol class="breadcrumb">';
		foreach($breadcumbs as $i=>$breadcumb){
		    echo "\n<li class=\"breadcrumb-item\"><a href=\"";
			for ($n=count($breadcumbs); $n > $i; $n--) { echo '../'; }
			echo "$breadcumb\">".ucfirst($breadcumb)."</a></li>";
		}
		echo "
		  </ol>
		</nav>\n";
		// exit();
		##BREDACUMB-BETA-TEST-MODE END##
}else{
	echo $breadcumb;
}
echo $content;