<?php 
$breadcumbs = explode("/",$_SERVER["REQUEST_URI"]);
$breadcumbs = (array_filter($breadcumbs));

echo '
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">';
foreach($breadcumbs as $i=>$breadcumb){
    echo "\n<li class=\"breadcrumb-item\"><a href=\"";
	for ($n=count($breadcumbs); $n > $i; $n--) { echo '../'; }
	echo "$breadcumb\">".ucfirst($breadcumb)."</a></li>";
}
echo "
  </ol>
</nav>\n";

echo $content;
?>	