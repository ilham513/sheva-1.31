<!doctype html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is my) Virtual Assistant AKA SHEVA">
    <meta name="author" content="iSetiaBhkati">

    <title>Sheva Indeks</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- JS include-->
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.min.js"></script>
	<link rel="icon" type="image/png" href="<?echo base_url();?>assets/icon/icon.png" />
	
	<style>
	html,
	body {
	  height: 100%;
	}

	#page-content {
	  flex: 1 0 auto;
	}

	#sticky-footer {
	  flex-shrink: none;
	}

	body {
	  background: #007bff;
	  background: linear-gradient(to right, #0062E6, #33AEFF);
	}
	</style>
  </head>

	<body class="d-flex flex-column">
	  <div id="page-content" style="padding:0px 0px 100px 0px">
		<div class="container text-center">
		  <div class="row justify-content-center">
			<div class="col-md-8" style="margin:59px 0px 40px;">
			  <h1 class="text-white">Pilih Tool</h1>
			</div>
			
			  <div class="container" >
				<div class="card-deck mb-2 text-center">
<div class="card mb-4 box-shadow">
  <div class="card-header">
	<h4 class="my-0 font-weight-normal">Sheva Stealer</h4>
  </div>
  <div class="card-body">
	<img src="assets/svg/mining.svg" width="90px" height="90px"/>
	<ul class="list-unstyled mt-3 mb-4">
	  <li>Simple HTML Scraper</li>
	  <li>Proxy Darurat</li>
	  <li>Data Minning</li>
	</ul>
	<a href="stealer"><button type="button" class="btn btn-lg btn-block btn-outline-primary">GO!</button></a>
  </div>
</div>
<div class="card mb-4 box-shadow">
  <div class="card-header">
	<h4 class="my-0 font-weight-normal">Sheva Sbot</h4>
  </div>
  <div class="card-body">
	<img src="assets/svg/user.svg" width="90px" height="90px"/>
	<ul class="list-unstyled mt-3 mb-4">
	  <li>Cari Konten Otomatis</li>
	  <li>Trend Finder</li>
	  <li>Automatic Content DB</li>
	</ul>
	<a href="sbot"><button type="button" class="btn btn-lg btn-block btn-outline-primary">GO!</button></a>
  </div>
</div>
<div class="card mb-4 box-shadow">
  <div class="card-header">
	<h4 class="my-0 font-weight-normal">Sheva WPoster</h4>
  </div>
  <div class="card-body">
	<img src="assets/svg/wordpress.svg" width="90px" height="90px"/>
	<ul class="list-unstyled mt-3 mb-4">
		<li>Posting Otomatis</li>
		<li>Poster Wordpress</li>
		<li>Kirim Artikel Direct</li>
	</ul>
	<a href="wposter"><button type="button" class="btn btn-lg btn-block btn-outline-primary">GO!</button></a>
  </div>
</div>
				</div>
			  </div>
		</div>
	  </div>
	  
	  <footer>
		<nav class="navbar fixed-bottom navbar-dark bg-dark">
		  <a class="navbar-brand" href="#">&copy; iSetiaBhakti - Since 2019</a>	
		  <img src="assets/svg/indonesia.svg" width="20px" height="20px"/>
		</nav>
	  </footer>
	</body>
</html>