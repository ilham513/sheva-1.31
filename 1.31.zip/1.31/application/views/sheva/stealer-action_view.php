<?php
$html = file_get_html($html_target);

// var_dump($target_propery); die();

foreach($html->find("$target") as $target_raw){ 
	// echo $target."<br/>"; die();
	if ($target_propery=='') { //jika gak ada property
		$fin_target = $target_raw;
	}else{ //jika ada
		$fin_target = $target_raw->$target_propery;
	}

	echo $fin_target."<br/>";
}

// var_dump($fin_target);
// foreach ($fin_target as $fin_target) {
// 	echo $fin_target."<br/>";
// }
?>