<?php
if (isset($_GET['html_target'])) 
{
$html = file_get_html($html_target);

 foreach($html->find("$target") as $target_raw){ 
	// echo $target."<br/>"; die();
	if ($target_propery=='') { //jika gak ada property
		$fin_target = $target_raw;
	}else{ //jika ada
		$fin_target = $target_raw->$target_propery;
	}

	echo $fin_target."<br/>";
 }
} 

else 

{
$attributes = array('id'=>'sbot_target','method'=>'get','class'=>'form_horizontal');
echo form_open('stealer/action',$attributes);

echo form_label('HTML Target');
$data = ['class'=>'form-control','name'=>'html_target',"placeholder"=>'http://site.com'];
echo form_input($data);

echo "<br/>";
echo form_label('Target');
$data = ['class'=>'form-control','name'=>'target',"placeholder"=>'tag[class=value] > child'];
echo form_input($data);

echo "<br/>";
echo form_label('Target Property*');
$data = ['class'=>'form-control','name'=>'target_propery',"placeholder"=>'href, plaintext, innertext, etc'];
echo form_input($data);

echo "<br/>\n";
$data = ['class'=>'btn btn-primary',"value"=>'GO!'];
echo form_submit($data);

echo form_close()."\n";
}
?>