<?php 
Class Sbot_model extends CI_Model{
	public function ambil_data(){
		// $query = $this->db->get('indeks2');
		$query = $this->db->query(" SELECT * FROM indeks2 ");

		return $query->result();
	}

	public function getindeks(){
		return 'indeks keambil';
	}

#ANIME

	public function anitokigetindeks(){
		// $html_target = base_url().'assets/html/anime-anitoki.html';
		$html_target = 'http://anitoki.com';
		$target = 'h2[class=episodeye] > a';
		$html = file_get_html($html_target);
		foreach($html->find("$target") as $tag)
			{
			 $urlnya = $tag->href; 

			 $this->db->query("
			 	INSERT IGNORE INTO `sbot_indeks` (`url`, `type`) 
			 	VALUES ('$urlnya', 'anime')
			 ");
			}
	}

	public function anitokiresetindeks(){
		$this->db->query("TRUNCATE sbot_indeks");
	}

	public function anitokigetpost(){
		
		$getpost = $this->db->query("SELECT url FROM sbot_indeks WHERE sts=0 LIMIT 1")->result();

		// ##var_dump($getpost);exit();
		if ($getpost==false) { echo 'QuerY hampa!'; exit(); }
		
		##TARGET-URL		
		$url_target = $getpost[0]->url;
		// $url_target = base_url().'assets/html/anime-anitoki-post.html'; //DUMMY URL



		$target = 'a[target=_blank]';
		$html = file_get_html($url_target);

		foreach($html->find("$target") as $obj){
			switch (substr($obj->plaintext, 0,3)) {
				case 'Zip':
					$zp[] = $obj->href;
					break;
				
				case 'Med':
					$mf[] = $obj->href;
					break;
				
				case 'Dri':
					$gd[] = $obj->href;
					break;
			}
		}

		$zp = array_slice($zp, 0, 3); #LIMIIT ARRAY
		$mf = array_slice($mf, 0, 3); #LIMIIT ARRAY
		$gd = array_slice($gd, 0, 3); #LIMIIT ARRAY

		$link = array_merge($zp,$mf,$gd);
		$link = implode("|", $link);
		// var_dump($link);

		$isi = $html->find('div[style=text-align: justify;]', 0)->plaintext;
		$judul = $html->find('h1', 0)->plaintext;
		$cover = $html->find('div.lexot > div > noscript > img', 0)->src; 
		// echo $cover; die(); ##KOPEKAN IMG LAZY SEARCH
		// $cover = $html->find('img', 1)->src;

		$a = $html->find('div.kategoz', 0)->plaintext;
		$b = explode(',', $a);
		$tanggal = preg_replace(array('/\s+/','/[^0-9,.]/'), '', $b[0]);
		// echo $tanggal;


		$injek = $this->db->query("
		INSERT INTO `sbot_anime` (`judul`, `cover`, `isi`, `link`, `sumber`, `tanggal`) 
		VALUES ('$judul', '$cover', '$isi', '$link', 'web-anitoki', CONCAT(YEAR(CURRENT_DATE),'-',MONTH(CURRENT_DATE),'-','$tanggal'))
		");

		// var_dump($injek);

		##JIKA GAGAL LANGSUNG EXIT!!
		if ($injek!=true) { echo 'INJEK ERRORR!'; exit();}

		##SUKSES SET sts = 1
		$this->db->query("UPDATE `sbot_indeks` SET `sts` = '1' WHERE `url` = '$url_target'");
		return $url_target;
	}

	public function youtubegetindeksto($table_name){

		##TESTER DUMMY PARAMETER
		$test = 'yes?'; /////////////////

		switch ($test) {
			case 'yes':
				$json = file_get_contents(base_url().'assets/json/youtube.json');
				break;
			
			default:
				$url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&chart=mostPopular&regionCode=ID&maxResults=20&key=AIzaSyCD-_GMRJY4Osx9f204YbcXZ8f4tloKqHY';

				$json = file_get_contents($url);
				break;
		}

		$data = json_decode($json);
		// $data = json_decode($json,true);

		// echo "<pre>";
		foreach ($data->items as $i=>$items) {
			// echo 'ID: '; var_dump($items->id);
			// echo 'Title: '; var_dump($items->snippet->title);
			// echo 'Date: '; var_dump(substr($items->snippet->publishedAt, 0,10));
			// echo 'Des: '; 	var_dump($items->snippet->description);
			// echo 'Thumb: '; var_dump($items->snippet->thumbnails->high->url);
			// echo 'Chann: '; var_dump($items->snippet->channelTitle);
			// echo 'Tag: '; 	var_dump(implode(',',$items->snippet->tags));

			// echo 'Durasi: ';var_dump($items->contentDetails->duration);

			// echo 'Hit: ';var_dump($items->statistics->viewCount);
			// echo 'Like: ';var_dump($items->statistics->likeCount);
			// echo 'Dislke: ';var_dump($items->statistics->dislikeCount);
			// echo 'Comm: ';var_dump($items->statistics->commentCount);
			// echo '<hr/>';

			$judul	=	$items->snippet->title;
			$judul	=	str_replace(array("'",'"'), "\'", $judul);

			$cover	=	$items->snippet->thumbnails->high->url;

			$isi	=	$items->snippet->description;
			$isi	=	str_replace(array("'",'"'), "\'", $isi);

			$link 	= 	$items->id;
			$sumber = 	$items->snippet->channelTitle;
			$tgl_pub=	substr($items->snippet->publishedAt, 0,10);
			$tgl_dep= 	'';
			$hit	=	$items->statistics->viewCount;
			
			$duration= 	$items->contentDetails->duration; //ANIEH SUMPAH!

			$tagg 	= 	implode(',',$items->snippet->tags);
			$tagg	=	str_replace(array("'",'"'), "\'", $tagg);

			$likee	=	$items->statistics->likeCount;
			$dislikee=	$items->statistics->dislikeCount;
			$commentt=	$items->statistics->commentCount;

			// $timestamp = '';

			// echo $judul	.'<hr/>';echo $cover	.'<hr/>';echo $isi	.'<hr/>';echo $link /*AS ID*/	.'<hr/>';echo $sumber .'<hr/>';echo $tgl_pub.'<hr/>';echo $tgl_dep.'<hr/>';echo $hit	,'<hr/><hr/><hr/><hr/>';


			##TESTER QUERY STRUCKTURE
			$this->db->query("
				INSERT IGNORE INTO `sbot_trend_youtube` 
				(`id_vid`, `title_vid`, `channel_name`, `hastag`, `duration`, `hit`, `likee`, `dislikee`, `commentt`) 
				VALUES ('$link', '$judul', '$sumber', '$tagg', '$duration', '$hit', '$likee', '$dislikee', '$commentt')
			");


			$this->db->query("
				INSERT IGNORE INTO `sbot_trend` (`judul`, `cover`, `isi`, `link`, `sumber`, `hit`, `tanggal`) 
				VALUES('$judul', '$cover', '$isi', '$link', '$sumber', '$hit', '$tgl_pub')
				");
		}

		// var_dump($data);

		return $table_name. ' Update Success.';
	}

	public function youtuberesetto($table_name){
		$this->db->query("TRUNCATE sbot_trend");
		// $this->db->query("TRUNCATE sbot_trend_youtube");
		return $table_name.' TELAH DIRESERT!1!';
	}
	
	public function selectanitoki(){
	   // echo 'select sukses!';
	    echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">';
	    $query = $this->db->get('sbot_anime');
	    foreach ($query->result() as $row){
            echo '<h1>'.$row->judul.'</h1><br/>';
            echo '<img src="'.$row->cover.'"><br/>';
            $link = $row->link;
            echo str_replace("|", "<br/>", $link);
            echo "<hr/>\n";
        }
	}
}